console.clear();

const {
	gsap: { to },
} = window;


const STAGGER_DEFAULTS = {
	yoyo: true,
	repeat: -1,
	each: 0.08,
	repeatDelay: 0.18,
};

to(".letters .letter", {
	y: -10,
	duration: 0.35,
	ease: "sine.inOut",
	stagger: STAGGER_DEFAULTS,
});

const STAR_DEFAULTS = {
	transformOrigin: "center",
	duration: 1,
	ease: "sine.InOut",
};

to(".letters .star", {
	...STAR_DEFAULTS,
	scale: 1.5,
	stagger: STAGGER_DEFAULTS,
});

to(".letters .star", {
	...STAR_DEFAULTS,
	rotation: 180,
	stagger: {
		...STAGGER_DEFAULTS,
		yoyo: false,
	},
});
